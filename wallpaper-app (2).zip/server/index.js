const express = require('express');
const multer = require('multer');
const cors = require('cors');
const fs = require('fs');
const path = require('path');

const app = express();
const PORT = process.env.PORT || 5000;

const UPLOADS_DIR = path.join(__dirname, 'uploads');
const DB_FILE = path.join(__dirname, 'data.json');

// ---------- tiny JSON store (no external DB needed) ----------
function loadDb() {
  try {
    return JSON.parse(fs.readFileSync(DB_FILE, 'utf-8'));
  } catch {
    return { wallpapers: [], nextId: 1 };
  }
}

function saveDb(db) {
  fs.writeFileSync(DB_FILE, JSON.stringify(db, null, 2));
}

// ---------- middleware ----------
app.use(cors());
app.use(express.json());
app.use('/uploads', express.static(UPLOADS_DIR));

// ---------- multer (image uploads) ----------
const storage = multer.diskStorage({
  destination: (_req, _file, cb) => cb(null, UPLOADS_DIR),
  filename: (_req, file, cb) => {
    const ext = path.extname(file.originalname).toLowerCase();
    cb(null, `${Date.now()}-${Math.round(Math.random() * 1e9)}${ext}`);
  },
});

const upload = multer({
  storage,
  limits: { fileSize: 15 * 1024 * 1024 }, // 15 MB
  fileFilter: (_req, file, cb) => {
    if (/^image\/(jpeg|jpg|png|webp|gif|avif)$/i.test(file.mimetype)) {
      cb(null, true);
    } else {
      cb(new Error('Only image files (jpeg/png/webp/gif/avif) are allowed'));
    }
  },
});

// ---------- routes ----------
app.get('/', (_req, res) => {
  res.json({ ok: true, message: 'Wallpaper API is running' });
});

// List — search / category filter / pagination / fetch-by-ids (favorites)
app.get('/api/wallpapers', (req, res) => {
  const { search = '', category = '', page = '1', limit = '12', ids = '' } = req.query;
  const db = loadDb();
  let items = [...db.wallpapers];

  if (ids) {
    const idSet = String(ids).split(',').map(Number);
    items = items.filter((w) => idSet.includes(w.id));
    return res.json({ wallpapers: items, total: items.length, page: 1, hasMore: false });
  }

  const q = String(search).trim().toLowerCase();
  if (q) {
    items = items.filter(
      (w) =>
        (w.title || '').toLowerCase().includes(q) ||
        (w.category || '').toLowerCase().includes(q) ||
        (w.tags || []).some((t) => t.includes(q))
    );
  }
  if (category) {
    const c = String(category).toLowerCase();
    items = items.filter((w) => (w.category || '').toLowerCase() === c);
  }

  items.sort((a, b) => b.id - a.id); // newest first

  const pageNum = Math.max(1, parseInt(page, 10) || 1);
  const limitNum = Math.min(60, Math.max(1, parseInt(limit, 10) || 12));
  const start = (pageNum - 1) * limitNum;
  const pageItems = items.slice(start, start + limitNum);

  res.json({
    wallpapers: pageItems,
    total: items.length,
    page: pageNum,
    hasMore: start + limitNum < items.length,
  });
});

// Distinct categories (for the filter dropdown)
app.get('/api/categories', (_req, res) => {
  const db = loadDb();
  const categories = [...new Set(db.wallpapers.map((w) => w.category).filter(Boolean))];
  res.json({ categories });
});

// Single wallpaper
app.get('/api/wallpapers/:id', (req, res) => {
  const db = loadDb();
  const w = db.wallpapers.find((x) => x.id === parseInt(req.params.id, 10));
  if (!w) return res.status(404).json({ error: 'Wallpaper not found' });
  res.json(w);
});

// Upload
app.post('/api/wallpapers', upload.single('image'), (req, res) => {
  if (!req.file) return res.status(400).json({ error: 'Image file is required' });

  const db = loadDb();
  const wallpaper = {
    id: db.nextId++,
    title: (req.body.title || 'Untitled').trim() || 'Untitled',
    category: (req.body.category || 'Other').trim() || 'Other',
    tags: String(req.body.tags || '')
      .split(',')
      .map((t) => t.trim().toLowerCase())
      .filter(Boolean),
    filename: req.file.filename,
    url: `/uploads/${req.file.filename}`,
    size: req.file.size,
    createdAt: new Date().toISOString(),
    downloads: 0,
  };
  db.wallpapers.push(wallpaper);
  saveDb(db);
  res.status(201).json(wallpaper);
});

// Download (increments counter, sends file as attachment)
app.get('/api/wallpapers/:id/download', (req, res) => {
  const db = loadDb();
  const w = db.wallpapers.find((x) => x.id === parseInt(req.params.id, 10));
  if (!w) return res.status(404).json({ error: 'Wallpaper not found' });

  const filePath = path.join(UPLOADS_DIR, w.filename);
  if (!fs.existsSync(filePath)) return res.status(410).json({ error: 'File is missing on disk' });

  w.downloads = (w.downloads || 0) + 1;
  saveDb(db);

  const safeName = `${w.title.replace(/[^\w.-]+/g, '_')}${path.extname(w.filename)}`;
  res.download(filePath, safeName);
});

// Delete
app.delete('/api/wallpapers/:id', (req, res) => {
  const db = loadDb();
  const idx = db.wallpapers.findIndex((x) => x.id === parseInt(req.params.id, 10));
  if (idx === -1) return res.status(404).json({ error: 'Wallpaper not found' });

  const [removed] = db.wallpapers.splice(idx, 1);
  saveDb(db);
  try {
    fs.unlinkSync(path.join(UPLOADS_DIR, removed.filename));
  } catch {
    // file already gone — ignore
  }
  res.json({ ok: true });
});

// Multer / generic error handler
app.use((err, _req, res, _next) => {
  res.status(err.status || 400).json({ error: err.message || 'Something went wrong' });
});

app.listen(PORT, () => {
  if (!fs.existsSync(UPLOADS_DIR)) fs.mkdirSync(UPLOADS_DIR);
  console.log(`Wallpaper API listening on http://localhost:${PORT}`);
});
