# PixelSaga Walls — Full-stack Wallpaper App

React (Vite) frontend + Node/Express backend. No external wallpaper API — you upload your own wallpapers.

## Features

- **Upload wallpapers** — JPEG/PNG/WebP/GIF/AVIF, up to 15 MB, with title, category and tags
- **Search** — debounced, matches title / category / tags
- **Filter by category** — dropdown built from your uploaded categories
- **Download button** — proper file download, tracks download count per wallpaper
- **Favorites** — tap the heart; saved per browser (localStorage), with a dedicated favorites view
- **Dark / Light mode** — one-click toggle, remembered across visits
- **Infinite scroll** — IntersectionObserver + paginated API (12 per page)
- **Delete** — remove wallpapers (and their files) you no longer want
- **Masonry grid** — responsive CSS columns, shows image resolution on load

## Project structure

```
wallpaper-app/
├── server/           # Node + Express API
│   ├── index.js      # all routes (upload, list, search, download, delete)
│   ├── uploads/      # image files (auto-created)
│   └── data.json     # metadata store (auto-created)
└── client/           # React + Vite frontend
    └── src/
        ├── App.jsx
        ├── api.js
        ├── styles.css
        └── components/
            ├── WallpaperCard.jsx
            └── UploadModal.jsx
```

## Running it (Node 18+ required)

**Terminal 1 — backend (port 5000):**

```bash
cd server
npm install
npm run dev
```

**Terminal 2 — frontend (port 5173):**

```bash
cd client
npm install
npm run dev
```

Then open http://localhost:5173 and start uploading.

## API endpoints

| Method | Endpoint                      | Purpose                              |
| ------ | ----------------------------- | ------------------------------------ |
| GET    | `/api/wallpapers`             | List — `?search=&category=&page=&limit=` |
| GET    | `/api/wallpapers?ids=1,2,3`   | Fetch specific ids (favorites view)  |
| POST   | `/api/wallpapers`             | Upload (multipart: `image`, `title`, `category`, `tags`) |
| GET    | `/api/wallpapers/:id`         | Single wallpaper                      |
| GET    | `/api/wallpapers/:id/download`| Download file (increments counter)   |
| DELETE | `/api/wallpapers/:id`         | Delete wallpaper + file              |
| GET    | `/api/categories`             | Distinct categories                   |

## Notes

- **No login system** — favorites are stored in the browser (localStorage), so they are per-device. Adding user accounts would be the natural next step.
- Storage is intentionally simple (files on disk + `data.json`); swap in MongoDB/PostgreSQL later if the collection grows large.
- To point the frontend at a different backend, create `client/.env` with `VITE_API_URL=http://your-api-host:5000`.
