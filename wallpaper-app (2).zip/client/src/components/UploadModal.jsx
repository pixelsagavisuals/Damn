import { useState } from 'react';
import { uploadWallpaper } from '../api';

export default function UploadModal({ categories, onClose, onUploaded }) {
  const [file, setFile] = useState(null);
  const [title, setTitle] = useState('');
  const [category, setCategory] = useState('');
  const [tags, setTags] = useState('');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');

  const submit = async (e) => {
    e.preventDefault();
    if (!file) {
      setError('Please choose an image file first.');
      return;
    }
    setBusy(true);
    setError('');
    try {
      const fd = new FormData();
      fd.append('image', file);
      fd.append('title', title);
      fd.append('category', category);
      fd.append('tags', tags);
      await uploadWallpaper(fd);
      onUploaded();
    } catch (err) {
      setError(err.message || 'Upload failed');
      setBusy(false);
    }
  };

  return (
    <div className="modal-backdrop" onClick={onClose}>
      <form className="modal" onClick={(e) => e.stopPropagation()} onSubmit={submit}>
        <h2>Upload wallpaper</h2>

        <input type="file" accept="image/*" onChange={(e) => setFile(e.target.files[0])} />

        <input
          placeholder="Title"
          value={title}
          onChange={(e) => setTitle(e.target.value)}
          maxLength={80}
        />

        <div>
          <input
            placeholder="Category (e.g. Nature, Abstract, Cars)"
            list="cat-list"
            value={category}
            onChange={(e) => setCategory(e.target.value)}
            maxLength={40}
          />
          <datalist id="cat-list">
            {categories.map((c) => (
              <option key={c} value={c} />
            ))}
          </datalist>
        </div>

        <input
          placeholder="Tags, comma separated (e.g. mountain, sunset, 4k)"
          value={tags}
          onChange={(e) => setTags(e.target.value)}
        />

        {error && <p className="error">{error}</p>}

        <div className="modal-actions">
          <button type="button" className="btn ghost" onClick={onClose}>
            Cancel
          </button>
          <button type="submit" className="btn primary" disabled={busy}>
            {busy ? 'Uploading…' : 'Upload'}
          </button>
        </div>
      </form>
    </div>
  );
}
