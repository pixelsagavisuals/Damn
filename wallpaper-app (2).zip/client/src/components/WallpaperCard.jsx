import { useState } from 'react';
import { imageUrl, downloadUrl, deleteWallpaper } from '../api';

export default function WallpaperCard({ w, isFavorite, onToggleFavorite, onDeleted }) {
  const [dims, setDims] = useState(null);

  const handleDelete = async () => {
    if (!window.confirm(`Delete "${w.title}"? This cannot be undone.`)) return;
    try {
      await deleteWallpaper(w.id);
      onDeleted(w.id);
    } catch (err) {
      window.alert(err.message || 'Delete failed');
    }
  };

  return (
    <div className="card">
      <img
        src={imageUrl(w)}
        alt={w.title}
        loading="lazy"
        onLoad={(e) =>
          setDims(`${e.target.naturalWidth} × ${e.target.naturalHeight}`)
        }
      />

      <div className="card-overlay">
        <div className="card-info">
          <span className="card-title">{w.title}</span>
          <span className="card-meta">
            <span className="chip">{w.category}</span>
            {dims && <span className="dims">{dims}</span>}
            <span className="downloads">{w.downloads || 0} downloads</span>
          </span>
        </div>

        <div className="card-actions">
          <button
            className={`icon-btn fav ${isFavorite ? 'active' : ''}`}
            title={isFavorite ? 'Remove from favorites' : 'Add to favorites'}
            onClick={() => onToggleFavorite(w.id)}
          >
            ♥
          </button>
          <a className="icon-btn" href={downloadUrl(w)} title="Download">
            ↓
          </a>
          <button className="icon-btn danger" title="Delete" onClick={handleDelete}>
            ✕
          </button>
        </div>
      </div>
    </div>
  );
}
