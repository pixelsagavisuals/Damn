const BASE = import.meta.env.VITE_API_URL || 'http://localhost:5000';

async function jsonFetch(url, options) {
  const res = await fetch(url, options);
  if (!res.ok) {
    let msg = `Request failed (${res.status})`;
    try {
      const body = await res.json();
      if (body.error) msg = body.error;
    } catch {
      // no JSON body
    }
    throw new Error(msg);
  }
  return res.json();
}

export async function fetchWallpapers({ search = '', category = '', page = 1, limit = 12, ids = '' } = {}) {
  const params = new URLSearchParams();
  if (search) params.set('search', search);
  if (category) params.set('category', category);
  if (ids) params.set('ids', ids);
  params.set('page', String(page));
  params.set('limit', String(limit));
  const data = await jsonFetch(`${BASE}/api/wallpapers?${params}`);
  return data; // { wallpapers, total, page, hasMore }
}

export async function fetchCategories() {
  const data = await jsonFetch(`${BASE}/api/categories`);
  return data.categories;
}

export async function uploadWallpaper(formData) {
  return jsonFetch(`${BASE}/api/wallpapers`, { method: 'POST', body: formData });
}

export async function deleteWallpaper(id) {
  return jsonFetch(`${BASE}/api/wallpapers/${id}`, { method: 'DELETE' });
}

export const imageUrl = (w) => `${BASE}${w.url}`;
export const downloadUrl = (w) => `${BASE}/api/wallpapers/${w.id}/download`;
