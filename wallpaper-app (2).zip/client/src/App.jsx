import { useEffect, useRef, useState } from 'react';
import { fetchWallpapers, fetchCategories } from './api';
import WallpaperCard from './components/WallpaperCard';
import UploadModal from './components/UploadModal';

const PAGE_SIZE = 12;

export default function App() {
  // ---- theme (dark / light, remembered) ----
  const [theme, setTheme] = useState(() => localStorage.getItem('theme') || 'dark');
  useEffect(() => {
    document.documentElement.dataset.theme = theme;
    localStorage.setItem('theme', theme);
  }, [theme]);

  // ---- data ----
  const [wallpapers, setWallpapers] = useState([]);
  const [categories, setCategories] = useState([]);
  const [page, setPage] = useState(1);
  const [hasMore, setHasMore] = useState(true);
  const [loading, setLoading] = useState(false);
  const [refreshKey, setRefreshKey] = useState(0);

  // ---- filters ----
  const [search, setSearch] = useState('');
  const [debouncedSearch, setDebouncedSearch] = useState('');
  const [category, setCategory] = useState('');

  // ---- ui ----
  const [showFavorites, setShowFavorites] = useState(false);
  const [showUpload, setShowUpload] = useState(false);
  const [favorites, setFavorites] = useState(() => {
    try {
      return JSON.parse(localStorage.getItem('favorites')) || [];
    } catch {
      return [];
    }
  });

  useEffect(() => {
    localStorage.setItem('favorites', JSON.stringify(favorites));
  }, [favorites]);

  useEffect(() => {
    fetchCategories()
      .then((cats) => setCategories(cats))
      .catch(() => {});
  }, [refreshKey]);

  // debounce the search box
  useEffect(() => {
    const t = setTimeout(() => setDebouncedSearch(search.trim()), 350);
    return () => clearTimeout(t);
  }, [search]);

  // go back to page 1 whenever filters / view change
  useEffect(() => {
    setPage(1);
  }, [debouncedSearch, category, showFavorites]);

  // ---- load wallpapers ----
  useEffect(() => {
    let cancelled = false;

    (async () => {
      // favorites view: fetch only the favorited ids
      if (showFavorites) {
        if (!favorites.length) {
          setWallpapers([]);
          setHasMore(false);
          return;
        }
        setLoading(true);
        try {
          const data = await fetchWallpapers({ ids: favorites.join(',') });
          if (!cancelled) {
            setWallpapers(data.wallpapers);
            setHasMore(false);
          }
        } finally {
          if (!cancelled) setLoading(false);
        }
        return;
      }

      // normal view: paginated + search + category
      setLoading(true);
      try {
        const data = await fetchWallpapers({
          search: debouncedSearch,
          category,
          page,
          limit: PAGE_SIZE,
        });
        if (!cancelled) {
          setWallpapers((prev) =>
            page === 1 ? data.wallpapers : [...prev, ...data.wallpapers]
          );
          setHasMore(data.hasMore);
        }
      } catch {
        if (!cancelled) setHasMore(false);
      } finally {
        if (!cancelled) setLoading(false);
      }
    })();

    return () => {
      cancelled = true;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [debouncedSearch, category, page, showFavorites, refreshKey]);

  // ---- infinite scroll ----
  const sentinelRef = useRef(null);
  useEffect(() => {
    const el = sentinelRef.current;
    if (!el) return;
    const observer = new IntersectionObserver(
      (entries) => {
        if (entries[0].isIntersecting && hasMore && !loading && !showFavorites) {
          setPage((p) => p + 1);
        }
      },
      { rootMargin: '600px 0px' }
    );
    observer.observe(el);
    return () => observer.disconnect();
  }, [hasMore, loading, showFavorites]);

  // ---- actions ----
  const toggleFavorite = (id) => {
    setFavorites((f) => (f.includes(id) ? f.filter((x) => x !== id) : [...f, id]));
    if (showFavorites) setWallpapers((ws) => ws.filter((w) => w.id !== id));
  };

  const handleUploaded = () => {
    setShowUpload(false);
    setPage(1);
    setRefreshKey((k) => k + 1);
  };

  const handleDeleted = (id) => {
    setWallpapers((ws) => ws.filter((w) => w.id !== id));
  };

  const showSkeleton = loading && page === 1 && !showFavorites;
  const showEmpty = !loading && wallpapers.length === 0;

  return (
    <div className="app">
      <header className="header">
        <div className="header-top">
          <h1 className="logo">
            Pixel<span>Saga</span> Walls
          </h1>
          <div className="header-actions">
            <button
              className={`btn ghost ${showFavorites ? 'active' : ''}`}
              onClick={() => setShowFavorites((v) => !v)}
            >
              {showFavorites ? 'All wallpapers' : `Favorites (${favorites.length})`}
            </button>
            <button
              className="btn ghost"
              onClick={() => setTheme((t) => (t === 'dark' ? 'light' : 'dark'))}
              title="Toggle theme"
            >
              {theme === 'dark' ? 'Light mode' : 'Dark mode'}
            </button>
            <button className="btn primary" onClick={() => setShowUpload(true)}>
              + Upload
            </button>
          </div>
        </div>

        <div className="toolbar">
          <input
            className="search"
            type="search"
            placeholder="Search by title, category or tag…"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
          />
          <select value={category} onChange={(e) => setCategory(e.target.value)}>
            <option value="">All categories</option>
            {categories.map((c) => (
              <option key={c} value={c}>
                {c}
              </option>
            ))}
          </select>
        </div>
      </header>

      <main>
        {showFavorites && <p className="notice">Your favorites — saved in this browser</p>}
        {showSkeleton && <p className="status">Loading…</p>}

        {showEmpty ? (
          <div className="empty">
            <p>
              {showFavorites
                ? 'No favorites yet — tap the heart on any wallpaper.'
                : 'No wallpapers found. Hit “+ Upload” to add your first one.'}
            </p>
          </div>
        ) : (
          <div className="grid">
            {wallpapers.map((w) => (
              <WallpaperCard
                key={w.id}
                w={w}
                isFavorite={favorites.includes(w.id)}
                onToggleFavorite={toggleFavorite}
                onDeleted={handleDeleted}
              />
            ))}
          </div>
        )}

        {loading && page > 1 && !showFavorites && <p className="status">Loading more…</p>}
        <div ref={sentinelRef} className="sentinel" />
      </main>

      {showUpload && (
        <UploadModal
          categories={categories}
          onClose={() => setShowUpload(false)}
          onUploaded={handleUploaded}
        />
      )}
    </div>
  );
}
